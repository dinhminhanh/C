#include <stdio.h>
#include <string.h>
#include "bai2.h"

Mess giao_dich_list[100]; // tao mang luu cac tin nhan va nhan toi da 100 mess nhap vao
int size = 0;

// kiem tra xem dong co hop le hay ko
int dong_hop_le(Mess mess) {
    int i;
    if( (mess.number >= 1 && mess.number <= 100) 
        && (mess.cost >= 1 && mess.cost <= 2000000)) {
            return 1;
    } else {
        return -1;
    }
}

treeType buildTree(int N) {
    treeType root;
    makeNullTree(&root);

    for (int i = 0; i < size; i++)
    {

       if(dong_hop_le(giao_dich_list[i]) == 1){
        insertNode(giao_dich_list[i], &root);
       }
    }
    printf("So nut trong cay: %d\n",countNode(root));
    return root;
}

int main() {
    char buff[1024];
    int i = 0;
    printf("Nhap theo dinh dang: DD-MM-YYYY seller buyer productID number cost: \n");
    char c = getchar();

    while(c != '$') {
        if(c == '\n') {
            buff[i] = '\0';
            sscanf(buff, "%s %s %s %s %d %d", 
                giao_dich_list[size].time, giao_dich_list[size].seller, 
                giao_dich_list[size].buyer, giao_dich_list[size].productID, 
                &giao_dich_list[size].number, &giao_dich_list[size].cost);
            i = 0;
            size++;
        }
        buff[i] = c;
        i++;
        c = getchar();
    }
    buff[i] = '\0';

    // kiá»ƒm tra tien hop le
    int N;
    printf("Nhap vao so N: ");
    scanf("%d",&N);

    treeType root;
    root = buildTree(size);
    int h = height(root);
    printf("Chieu cao cua cay: %d\n", h);
} 