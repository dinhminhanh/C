#include<stdio.h>
#include<stdlib.h>
#include<string.h>


//THU VIEN DANH CHO CAY NHI PHAN TIM KIEM (BST)

//typedef ... elementtype;
//Whatever type of element

typedef struct mess{
    char time[11]; //DD-MM-YYYY
    char seller[256];
    char buyer[256];
    char productID[256];
    int number; // 1 <= number <= 100
    int cost; // 1 <= cost <= 200 man
}Mess;

typedef struct node_type{
  Mess element;
  struct node_type *left, *right;
}nodeType;

typedef nodeType *treeType; //treetype la 1 con tro tro den kieu Node. treeType = Node*

//Ham so sanh 2 phan tu dang elementType bat ky
// tra ve 1 -> a > b, 0 -> a = b, -1 -> a < b
int compare(Mess a, Mess b){
  if( a.cost > b.cost )
    return 1;
  else if(a.cost == b.cost) {
    int check = strcmp(a.productID, b.productID);
    if( check > 0) {
        return 1;
    } else if(check == 0) {

        int check = strcmp(a.time, b.time); 
        if(check < 0) {
            return 1;
        } else if(check == 0) {
            char tmp_a[513], tmp_b[513];
            sprintf(tmp_a, "%s-%s",a.seller, a.buyer);
            sprintf(tmp_b, "%s-%s",b.seller, b.buyer);
            int check = strcmp(tmp_a, tmp_b);
            if(check < 0) {
                return 1;
            } else if(check == 0) {
                return 0;
            } else if(check > 0) {
                return -1;
            }
        } else if( check > 0) {
            return -1;
        }
    } else if(check < 0) {
        return -1;
    }
  } else if(a.cost < b.cost) {
    return -1;
  }
}

//1. Khoi tao cay rong
void makeNullTree(treeType *T){
  (*T) = NULL;
}

//2. Xem lieu co phai cay rong ko
int isEmptyTree(treeType T){
  return T == NULL;
}

//3. Lay con trai
treeType leftChild(treeType n){
  if(n != NULL) return n->left;
  else return NULL;
}

//4. Lay con phai
treeType rightChild(treeType n){
  if(n != NULL) return n->right;
  else return NULL;
}

//7. Dem so node trong cay
int countNode(treeType T){
  if(isEmptyTree(T)) return 0;
  else return 1 + countNode(leftChild(T)) + countNode(rightChild(T));
}

//9. Tao cay tim kiem nhi phan
void insertNode(Mess x, treeType *root){    //Neu truyen vao con tro -> thay doi ca tree. Neu chi truyen vao root bthg -> phai return de lay gia tri
  if(*root == NULL){//Truong hop co so: nut rong
    /*Create a new node for key x*/
    *root = (nodeType*)malloc(sizeof(nodeType));
    (*root)->element= x;
    (*root)->left = NULL; 
    (*root)->right = NULL;
  }
  else if(compare(x, (*root)->element) < 0)//Neu khoa them vao < khoa nut goc 
    insertNode(x, &(*root)->left);
  
  else if(compare(x, (*root)->element) > 0)
    insertNode(x, &(*root)->right);
  else if(compare(x, (*root)->element) == 0) {
    (*root)->element.number += x.number;
    (*root)->element.cost += x.cost;
  }
}

int max(int a, int b){
  if(a > b)
    return a;
  return b;
}

//11. Tinh chieu cao cay
int height(treeType root){
  if(root == NULL)
    return -1;
  else return max(height(root->left), height(root->right)) + 1;
}

//15. Ham duyet cay theo thu tu giua
void inOrderPrint(treeType root){
  if(root != NULL){
    inOrderPrint(root->left);
    printf("%s-%s-%s-%s-%d-%d\n", root->element.time, root->element.seller, root->element.buyer, root->element.productID, root->element.number, root->element.cost);
    inOrderPrint(root->right);
  }
}