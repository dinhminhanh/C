#include <stdio.h>
#include <string.h>

// 24-02-2023 john peter 45E1 12 360
typedef struct mess{
    char time[11]; //DD-MM-YYYY
    char seller[256];
    char buyer[256];
    char productID[256];
    int number; // 1 <= number <= 100
    int cost; // 1 <= cost <= 200 man
}Mess;

Mess giao_dich_list[100]; // tao mang luu cac tin nhan va nhan toi da 100 mess nhap vao

// cau a
void tien_hop_le(int size) {
    int i, count = 0;
    for(i = 0; i < size; i++) {
        // tien lon hon 1 va nho hon 200 man (200 0000)
        if(giao_dich_list[i].cost >= 1 && giao_dich_list[i].cost <= 2000000) {
            count++;
        }
    }
    printf("So dong thoa man tien hop le: %d\n", count);
}

// cau b 
void number_hop_le(int size) {
    int i, count = 0;
    for(i = 0; i < size; i++) {
        // 1 <= number <= 100
        if(giao_dich_list[i].number >= 1 && giao_dich_list[i].number <= 100) {
            count++;
        }
    }
    printf("So dong thoa man number hop le: %d\n", count);
}

// cau c
void max_tien(int size) {
    int i;
    float max = giao_dich_list[0].cost / giao_dich_list[0].number;

    // tim max
    for(i = 1; i < size; i++) {
        float gia_tren_1sp = giao_dich_list[i].cost / giao_dich_list[i].number;
        if(gia_tren_1sp >= max) {
            max = gia_tren_1sp;
        }
    }
    // tim dong co cost max
    for(i = 1; i < size; i++) {
        float gia_tren_1sp = giao_dich_list[i].cost / giao_dich_list[i].number;
        if(gia_tren_1sp == max) {
            printf("Dong co so tien tren 1 san pham cao nhat: %d\n", i);
            return;
        }
    }
}

int main() {
    char buff[1024];
    int i = 0, size = 0;
    printf("Nhap theo dinh dang: DD-MM-YYYY seller buyer productID number cost: \n");
    char c = getchar();

    while(c != '$') {
        if(c == '\n') {
            buff[i] = '\0';
            sscanf(buff, "%s %s %s %s %d %d", 
                giao_dich_list[size].time, giao_dich_list[size].seller, 
                giao_dich_list[size].buyer, giao_dich_list[size].productID, 
                &giao_dich_list[size].number, &giao_dich_list[size].cost);
            i = 0;
            size++;
        }
        buff[i] = c;
        i++;
        c = getchar();
    }
    buff[i] = '\0';

    // kiá»ƒm tra tien hop le
    tien_hop_le(size); // cau a
    number_hop_le(size); // cau b
    max_tien(size); // cau c
} 